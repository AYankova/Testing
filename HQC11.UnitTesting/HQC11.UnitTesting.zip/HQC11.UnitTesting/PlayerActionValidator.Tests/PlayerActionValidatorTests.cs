﻿namespace PlayerActionValidator.Tests
{
    using System;
    using System.Collections.Generic;
    using NUnit.Framework;
    using Santase.ConsoleUI;
    using Santase.Logic;
    using Santase.Logic.Cards;
    using Santase.Logic.Players;
    using Santase.Logic.RoundStates;

    // TODO: Implement more unit tests for IsValid
    [TestFixture]
    public class PlayerActionValidatorTests
    {
        [Test]
        public void IsValidShouldReturnFalseWhenPlayerCardsDontContainActionCard()
        {
            var action = new PlayerAction(PlayerActionType.PlayCard, new Card(CardSuit.Club, CardType.King), Announce.None);
            var gameRound = new GameRound(new ConsolePlayer(3, 5), new ConsolePlayer(2, 4), PlayerPosition.FirstPlayer);
            var context = new PlayerTurnContext(new StartRoundState(gameRound), new Card(CardSuit.Diamond, CardType.Ten), 6);
            IList<Card> playerCards = new List<Card>() { new Card(CardSuit.Diamond, CardType.Jack), new Card(CardSuit.Diamond, CardType.Queen), new Card(CardSuit.Club, CardType.Ace), new Card(CardSuit.Club, CardType.Nine), new Card(CardSuit.Spade, CardType.Ten), new Card(CardSuit.Spade, CardType.Queen) };
            var validator = new PlayerActionValidater();
            var isValid = validator.IsValid(action, context, playerCards);

            Assert.IsFalse(isValid);
        }

        [Test]
        public void IsValidShouldReturnTrueWhenPlayerCardsContainActionCard()
        {
            var action = new PlayerAction(PlayerActionType.PlayCard, new Card(CardSuit.Club, CardType.King), Announce.None);
            var gameRound = new GameRound(new ConsolePlayer(3, 5), new ConsolePlayer(2, 4), PlayerPosition.FirstPlayer);
            var context = new PlayerTurnContext(new StartRoundState(gameRound), new Card(CardSuit.Diamond, CardType.Ten), 6);
            IList<Card> playerCards = new List<Card>() { new Card(CardSuit.Diamond, CardType.Jack), new Card(CardSuit.Diamond, CardType.Queen), new Card(CardSuit.Club, CardType.King), new Card(CardSuit.Club, CardType.Nine), new Card(CardSuit.Spade, CardType.Ten), new Card(CardSuit.Spade, CardType.Queen) };
            var validator = new PlayerActionValidater();
            var isValid = validator.IsValid(action, context, playerCards);

            Assert.IsTrue(isValid);
        }

        [Test]
        public void IsValidShouldReturnTrueWhenPlayerCardsContainTwentyAndPlayerAnnouncesTwenty()
        {
            var action = new PlayerAction(PlayerActionType.PlayCard, new Card(CardSuit.Club, CardType.King), Announce.Twenty);
            var gameRound = new GameRound(new ConsolePlayer(3, 5), new ConsolePlayer(2, 4), PlayerPosition.FirstPlayer);
            var context = new PlayerTurnContext(new StartRoundState(gameRound), new Card(CardSuit.Diamond, CardType.Ten), 6);
            IList<Card> playerCards = new List<Card>() { new Card(CardSuit.Diamond, CardType.Nine), new Card(CardSuit.Diamond, CardType.Ace), new Card(CardSuit.Club, CardType.King), new Card(CardSuit.Club, CardType.Queen), new Card(CardSuit.Spade, CardType.Ten), new Card(CardSuit.Spade, CardType.Queen) };
            var validator = new PlayerActionValidater();
            var isValid = validator.IsValid(action, context, playerCards);

            Assert.IsTrue(isValid);
        }

        [Test]
        public void IsValidShouldReturnTrueWhenPlayerCardsContainFortyAndPlayerAnnouncesForty()
        {
            var action = new PlayerAction(PlayerActionType.PlayCard, new Card(CardSuit.Club, CardType.King), Announce.Fourty);
            var gameRound = new GameRound(new ConsolePlayer(3, 5), new ConsolePlayer(2, 4), PlayerPosition.FirstPlayer);
            var context = new PlayerTurnContext(new StartRoundState(gameRound), new Card(CardSuit.Club, CardType.Ten), 6);
            IList<Card> playerCards = new List<Card>() { new Card(CardSuit.Diamond, CardType.Nine), new Card(CardSuit.Diamond, CardType.Ace), new Card(CardSuit.Club, CardType.King), new Card(CardSuit.Club, CardType.Queen), new Card(CardSuit.Spade, CardType.Ten), new Card(CardSuit.Spade, CardType.Queen) };
            var validator = new PlayerActionValidater();
            var isValid = validator.IsValid(action, context, playerCards);

            Assert.IsTrue(isValid);
        }

        [Test]
        public void IsValidShouldReturnFalseWhenPlayerTriesToChangeTrump()
        {
            var action = new PlayerAction(PlayerActionType.ChangeTrump, new Card(CardSuit.Club, CardType.Nine), Announce.None);
            var gameRound = new GameRound(new ConsolePlayer(3, 5), new ConsolePlayer(2, 4), PlayerPosition.FirstPlayer);
            var context = new PlayerTurnContext(new StartRoundState(gameRound), new Card(CardSuit.Club, CardType.Ace), 6);
            IList<Card> playerCards = new List<Card>() { new Card(CardSuit.Diamond, CardType.Nine), new Card(CardSuit.Diamond, CardType.Ace), new Card(CardSuit.Club, CardType.King), new Card(CardSuit.Diamond, CardType.Queen), new Card(CardSuit.Spade, CardType.Ten), new Card(CardSuit.Spade, CardType.Queen) };
            var validator = new PlayerActionValidater();
            var isValid = validator.IsValid(action, context, playerCards);

            Assert.IsFalse(isValid);
        }
    }
}
