﻿namespace Santase.Logic.Cards
{
    public enum CardSuit
    {
        Club,
        Diamond,
        Heart,
        Spade,
    }
}