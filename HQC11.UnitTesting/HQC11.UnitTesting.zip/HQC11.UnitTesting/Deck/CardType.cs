﻿namespace Santase.Logic.Cards
{
    public enum CardType
    {
        Nine,
        Ten,
        Jack,
        Queen,
        King,
        Ace,
    }
}