﻿namespace Santase.Logic.Players
{
    public enum PlayerActionType
    {
        PlayCard,
        CloseGame,
        ChangeTrump,
    }
}